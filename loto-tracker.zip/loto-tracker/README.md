# 🎱 Loto Tracker

Classeur des tirages du Loto français depuis l'an 2000, avec suivi des retards en temps réel.

## Fonctionnement des retards

- Numéro **tiré** → valeur = **0**
- Numéro **non tiré** → valeur **+1**
- Couleurs : vert (vient d'être tiré) → rouge (très en retard)

## Architecture temps réel

```
FDJ Open Data (ZIP/CSV)
       ↓
  /api/sync  ←── Vercel Cron (Lun/Mer/Sam à 22h)
       ↓
  Vercel KV  (base de données persistante)
       ↓
  /api/tirages  ←── Frontend (scroll infini)
```

## Déploiement complet sur Vercel

### Étape 1 — Push sur GitHub

```bash
git init
git add .
git commit -m "feat: loto tracker"
git branch -M main
git remote add origin https://github.com/TON_USER/loto-tracker.git
git push -u origin main
```

### Étape 2 — Créer le projet Vercel

1. [vercel.com](https://vercel.com) → **Add New Project**
2. Importer le repo GitHub
3. Framework: **Next.js** (auto-détecté)
4. Cliquer **Deploy**

### Étape 3 — Activer Vercel KV (base de données)

> Sans KV, les données fonctionnent en mémoire (pas persistantes).
> Avec KV, tous les tirages sont sauvegardés définitivement.

1. Dans ton projet Vercel → onglet **Storage**
2. Cliquer **Create Database** → choisir **KV**
3. Nommer la base `loto-kv`, cliquer **Create**
4. Aller dans **Settings** de la base → **Connect to project** → sélectionner ton projet
5. Redéployer le projet (push un commit vide) :
   ```bash
   git commit --allow-empty -m "chore: connect kv"
   git push
   ```

### Étape 4 — Premier chargement

Au premier accès, le site importe automatiquement **tous les tirages depuis 2000** depuis les données ouvertes FDJ.
Cela peut prendre 30-60 secondes.

### Étape 5 (optionnel) — Sécuriser le cron

Dans **Vercel → Settings → Environment Variables**, ajouter :
```
CRON_SECRET = une_chaine_secrete_longue
```

Cela empêche des appels non autorisés à `/api/sync`.

## Fonctionnement automatique

Le cron Vercel appelle `/api/sync` automatiquement :
- **Lundi** à 22h00
- **Mercredi** à 22h00  
- **Samedi** à 22h00

(Jours et heure des tirages du Loto français)

Chaque sync ne récupère que les **nouveaux tirages** depuis le dernier enregistré.

## Mise à jour manuelle

Appuyer sur le bouton 🔄 dans l'app, ou appeler directement :
```
GET /api/sync?force=true
```

## Vérifier l'état

```
GET /api/admin
```

Retourne : nombre de tirages, date du plus récent, dernière sync, état KV.

## Stack

- **Next.js 14** App Router + TypeScript
- **Vercel KV** (Redis) pour le stockage persistant
- **Vercel Cron** pour la mise à jour automatique
- **FDJ Open Data** comme source de données
- **CSS-in-JSX** mobile-first

## Développement local

```bash
npm install
# Optionnel: configurer .env.local avec les credentials KV
# (sans KV, fonctionne en mode mémoire)
cp .env.local.example .env.local
npm run dev
```

### .env.local (KV local)
Récupérer les variables depuis Vercel → Storage → ton KV → `.env.local` tab :
```
KV_URL=...
KV_REST_API_URL=...
KV_REST_API_TOKEN=...
KV_REST_API_READ_ONLY_TOKEN=...
```
