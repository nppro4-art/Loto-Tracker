# 🎱 Loto Tracker

Classeur des tirages du Loto français depuis 2000 avec retards et fréquences en temps réel.

## Déploiement complet (tout sur navigateur)

### 1. Mettre les fichiers sur GitHub
1. github.com → **New repository** → nommer `loto-tracker` → cocher "Add README" → **Create**
2. Dans le repo → **Add file** → **Upload files**
3. Glisser-déposer **le contenu** du dossier dézippé → **Commit changes**

### 2. Déployer sur Vercel
1. vercel.com → connecter avec GitHub → **Add New Project**
2. Choisir `loto-tracker` → laisser tout par défaut → **Deploy**

### 3. Activer la base de données Upstash (remplace l'ancien KV)
1. Dans ton projet Vercel → **Storage** dans la barre gauche
2. **Browse Marketplace** → chercher **Upstash** → **Upstash Redis**
3. **Install** → **Add Integration** → choisir ton projet
4. Vercel injecte automatiquement les variables `UPSTASH_REDIS_REST_URL` et `UPSTASH_REDIS_REST_TOKEN`
5. **Redeploy** ton projet (bouton dans l'onglet Deployments)

### 4. Premier accès
Au premier chargement du site, tous les tirages depuis 2000 sont importés automatiquement (30-60 sec).

### 5. Mises à jour automatiques
Le cron Vercel appelle `/api/sync` chaque **lundi, mercredi et samedi à 22h** pour récupérer les nouveaux tirages.
Le bouton 🔄 dans l'app permet une mise à jour manuelle.

## Variables d'environnement (auto-injectées par Upstash)
```
UPSTASH_REDIS_REST_URL=...
UPSTASH_REDIS_REST_TOKEN=...
```
