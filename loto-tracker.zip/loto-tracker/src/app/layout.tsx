import type { Metadata, Viewport } from "next";

export const metadata: Metadata = {
  title: "Loto Tracker — Tirages depuis 2000",
  description: "Classeur des tirages du Loto français avec suivi des retards depuis l'an 2000",
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#1a0533",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body>{children}</body>
    </html>
  );
}
