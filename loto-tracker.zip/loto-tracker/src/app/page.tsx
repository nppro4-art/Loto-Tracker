"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { LotoTirage, computeRetards, TirageDisplay, formatDate, retardColor, MAX_BOULE, MAX_CHANCE } from "@/lib/loto";

const MAX_RETARD_BOULE = 120;
const MAX_RETARD_CHANCE = 50;

export default function Home() {
  const [tirages, setTirages] = useState<LotoTirage[]>([]);
  const [displayed, setDisplayed] = useState<TirageDisplay[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [activeView, setActiveView] = useState<"tableau" | "stats">("tableau");
  const [showLegend, setShowLegend] = useState(false);
  const [lastSync, setLastSync] = useState<string | null>(null);
  const [dataSource, setDataSource] = useState<"kv" | "memory" | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [syncMsg, setSyncMsg] = useState<string | null>(null);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const loadMoreRef = useRef<HTMLDivElement | null>(null);
  const allTiragesRef = useRef<LotoTirage[]>([]);

  const fetchPage = useCallback(async (p: number, q: string, append: boolean) => {
    try {
      if (p === 1) setLoading(true);
      else setLoadingMore(true);

      const res = await fetch(`/api/tirages?page=${p}&perPage=50&search=${encodeURIComponent(q)}`);
      if (!res.ok) throw new Error("Erreur réseau");
      const data = await res.json();

      if (data.error) throw new Error(data.error);

      const newTirages: LotoTirage[] = data.tirages;
      setTotal(data.total);
      setTotalPages(data.totalPages);
      if (data.lastSync) setLastSync(data.lastSync);
      if (data.source) setDataSource(data.source as "kv" | "memory");

      if (append) {
        allTiragesRef.current = [...allTiragesRef.current, ...newTirages];
      } else {
        allTiragesRef.current = newTirages;
      }

      // We need ALL tirages to compute correct retards, but we only show paginated
      // For display: compute retards on all loaded so far
      const computed = computeRetards(allTiragesRef.current);
      setDisplayed(computed);
      setTirages(allTiragesRef.current);
    } catch (e: any) {
      setError(e.message || "Erreur inconnue");
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, []);

  useEffect(() => {
    fetchPage(1, search, false);
  }, [search]);

  // Infinite scroll
  useEffect(() => {
    if (observerRef.current) observerRef.current.disconnect();
    observerRef.current = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !loadingMore && page < totalPages) {
          const next = page + 1;
          setPage(next);
          fetchPage(next, search, true);
        }
      },
      { threshold: 0.1 }
    );
    if (loadMoreRef.current) observerRef.current.observe(loadMoreRef.current);
    return () => observerRef.current?.disconnect();
  }, [page, totalPages, loadingMore, search, fetchPage]);

  const handleSearch = () => {
    setSearch(searchInput);
    setPage(1);
    allTiragesRef.current = [];
  };

  const handleManualSync = async () => {
    setSyncing(true);
    setSyncMsg(null);
    try {
      const res = await fetch("/api/sync?force=true");
      const data = await res.json();
      if (data.error) {
        setSyncMsg("❌ " + data.error);
      } else if (data.status === "up_to_date") {
        setSyncMsg("✅ Déjà à jour — " + (data.newestDate || ""));
      } else {
        setSyncMsg(`✅ ${data.saved} nouveau(x) tirage(s) ajouté(s) !`);
        // Reload data
        setPage(1);
        allTiragesRef.current = [];
        fetchPage(1, search, false);
      }
    } catch {
      setSyncMsg("❌ Erreur de connexion");
    } finally {
      setSyncing(false);
      setTimeout(() => setSyncMsg(null), 5000);
    }
  };

  // Stats: most overdue numbers
  const lastTirage = displayed[0];
  const topRetards = lastTirage
    ? Object.entries(lastTirage.retards)
        .map(([n, r]) => ({ numero: parseInt(n), retard: r }))
        .sort((a, b) => b.retard - a.retard)
        .slice(0, 10)
    : [];

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-inner">
          <div className="logo">
            <span className="logo-icon">🎱</span>
            <div>
              <h1>LOTO TRACKER</h1>
              <p className="subtitle">Tirages depuis 2000</p>
            </div>
          </div>
          <div className="header-right">
            {total > 0 && (
              <div className="total-badge">{total.toLocaleString("fr-FR")} tirages</div>
            )}
            <button
              className={`sync-btn ${syncing ? "syncing" : ""}`}
              onClick={handleManualSync}
              disabled={syncing}
              title="Synchroniser les nouveaux tirages"
            >
              {syncing ? "⏳" : "🔄"}
            </button>
          </div>
        </div>

        {/* Nav tabs */}
        <div className="tabs">
          <button
            className={`tab ${activeView === "tableau" ? "active" : ""}`}
            onClick={() => setActiveView("tableau")}
          >
            📋 Tableau
          </button>
          <button
            className={`tab ${activeView === "stats" ? "active" : ""}`}
            onClick={() => setActiveView("stats")}
          >
            📊 Stats
          </button>
        </div>
      </header>

      <main className="main">
        {/* Search */}
        <div className="search-bar">
          <input
            type="text"
            placeholder="Rechercher par année (ex: 2023)"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            className="search-input"
          />
          <button onClick={handleSearch} className="search-btn">🔍</button>
        </div>

        {/* Sync status bar */}
        {(lastSync || dataSource) && (
          <div className="sync-bar">
            {dataSource === "kv" && <span className="sync-dot live" title="Données persistantes">● Live</span>}
            {dataSource === "memory" && <span className="sync-dot mem" title="Cache mémoire (KV non configuré)">● Cache</span>}
            {lastSync && (
              <span className="sync-time">
                Sync: {new Date(lastSync).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" })}
              </span>
            )}
          </div>
        )}
        {syncMsg && <div className="sync-msg">{syncMsg}</div>}

        {/* Legend toggle */}
        <button className="legend-toggle" onClick={() => setShowLegend(!showLegend)}>
          {showLegend ? "▲" : "▼"} Légende des couleurs
        </button>
        {showLegend && (
          <div className="legend">
            <div className="legend-item">
              <span className="legend-color" style={{ background: "#00e676" }}></span>
              <span>0 = tiré ce jour</span>
            </div>
            <div className="legend-item">
              <span className="legend-color" style={{ background: "#e8f5e9" }}></span>
              <span>Faible retard</span>
            </div>
            <div className="legend-item">
              <span className="legend-color" style={{ background: "#fff9c4" }}></span>
              <span>Retard moyen</span>
            </div>
            <div className="legend-item">
              <span className="legend-color" style={{ background: "#ffe0b2" }}></span>
              <span>Retard élevé</span>
            </div>
            <div className="legend-item">
              <span className="legend-color" style={{ background: "#ef9a9a" }}></span>
              <span>Très en retard</span>
            </div>
          </div>
        )}

        {loading && (
          <div className="loading">
            <div className="spinner"></div>
            <p>Chargement des tirages...</p>
          </div>
        )}

        {error && (
          <div className="error">
            <p>⚠️ {error}</p>
            <button onClick={() => fetchPage(1, search, false)}>Réessayer</button>
          </div>
        )}

        {/* TABLEAU VIEW */}
        {!loading && activeView === "tableau" && displayed.length > 0 && (
          <div className="tableau-container">
            {displayed.map((tirage, idx) => (
              <TirageCard key={`${tirage.date}-${idx}`} tirage={tirage} />
            ))}

            {/* Infinite scroll trigger */}
            <div ref={loadMoreRef} className="load-more">
              {loadingMore && (
                <div className="loading-more">
                  <div className="spinner small"></div>
                  <span>Chargement...</span>
                </div>
              )}
              {!loadingMore && page >= totalPages && (
                <p className="end-message">✅ Tous les tirages sont chargés</p>
              )}
            </div>
          </div>
        )}

        {/* STATS VIEW */}
        {!loading && activeView === "stats" && lastTirage && (
          <StatsView tirage={lastTirage} topRetards={topRetards} allDisplayed={displayed} />
        )}
      </main>

      <style jsx global>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
          font-family: 'Courier New', monospace;
          background: #0a0a0f;
          color: #e0e0e0;
          min-height: 100vh;
          -webkit-font-smoothing: antialiased;
        }

        .app { max-width: 480px; margin: 0 auto; min-height: 100vh; }

        /* HEADER */
        .header {
          background: linear-gradient(135deg, #1a0533 0%, #0d1f3c 100%);
          border-bottom: 2px solid #6c3fc5;
          position: sticky;
          top: 0;
          z-index: 100;
          box-shadow: 0 4px 20px rgba(108,63,197,0.3);
        }

        .header-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 12px 16px 8px;
        }

        .logo { display: flex; align-items: center; gap: 10px; }
        .logo-icon { font-size: 28px; }
        .logo h1 { font-size: 18px; font-weight: 900; letter-spacing: 3px; color: #c084fc; text-shadow: 0 0 20px rgba(192,132,252,0.5); }
        .subtitle { font-size: 10px; color: #888; letter-spacing: 1px; margin-top: 2px; }

        .total-badge {
          background: rgba(108,63,197,0.3);
          border: 1px solid #6c3fc5;
          color: #c084fc;
          font-size: 11px;
          padding: 4px 8px;
          border-radius: 20px;
          font-weight: bold;
        }

        .tabs {
          display: flex;
          border-top: 1px solid rgba(108,63,197,0.3);
        }

        .tab {
          flex: 1;
          padding: 10px;
          background: transparent;
          border: none;
          color: #888;
          font-family: 'Courier New', monospace;
          font-size: 13px;
          cursor: pointer;
          transition: all 0.2s;
          letter-spacing: 1px;
        }

        .tab.active {
          color: #c084fc;
          background: rgba(108,63,197,0.15);
          border-bottom: 2px solid #c084fc;
        }

        /* MAIN */
        .main { padding: 12px; }

        .search-bar {
          display: flex;
          gap: 8px;
          margin-bottom: 10px;
        }

        .search-input {
          flex: 1;
          background: #111827;
          border: 1px solid #374151;
          color: #e0e0e0;
          padding: 10px 12px;
          border-radius: 8px;
          font-family: 'Courier New', monospace;
          font-size: 13px;
          outline: none;
          transition: border-color 0.2s;
        }

        .search-input:focus { border-color: #6c3fc5; }

        .search-btn {
          background: #6c3fc5;
          border: none;
          color: white;
          padding: 10px 14px;
          border-radius: 8px;
          cursor: pointer;
          font-size: 16px;
        }

        .legend-toggle {
          background: transparent;
          border: 1px solid #374151;
          color: #888;
          font-size: 11px;
          padding: 6px 12px;
          border-radius: 6px;
          cursor: pointer;
          font-family: 'Courier New', monospace;
          margin-bottom: 8px;
          width: 100%;
          text-align: left;
        }

        .legend {
          background: #111827;
          border: 1px solid #374151;
          border-radius: 8px;
          padding: 12px;
          margin-bottom: 12px;
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .legend-item { display: flex; align-items: center; gap: 6px; font-size: 11px; }
        .legend-color { width: 16px; height: 16px; border-radius: 3px; flex-shrink: 0; border: 1px solid rgba(0,0,0,0.2); }

        /* TIRAGE CARD */
        .tirage-card {
          background: #111827;
          border: 1px solid #1f2937;
          border-radius: 10px;
          margin-bottom: 12px;
          overflow: hidden;
          transition: border-color 0.2s;
        }

        .tirage-card:first-child { border-color: #6c3fc5; box-shadow: 0 0 15px rgba(108,63,197,0.2); }

        .card-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: #0d1117;
          border-bottom: 1px solid #1f2937;
        }

        .card-date {
          font-size: 13px;
          font-weight: bold;
          color: #c084fc;
          letter-spacing: 1px;
        }

        .card-label {
          font-size: 10px;
          color: #555;
          letter-spacing: 1px;
          text-transform: uppercase;
        }

        .drawn-balls {
          display: flex;
          gap: 6px;
          padding: 10px 12px;
          flex-wrap: wrap;
          align-items: center;
        }

        .ball {
          width: 34px;
          height: 34px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 900;
          background: radial-gradient(circle at 35% 35%, #7c3aed, #4c1d95);
          color: white;
          box-shadow: 0 2px 8px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.2);
          flex-shrink: 0;
        }

        .ball.chance {
          background: radial-gradient(circle at 35% 35%, #dc2626, #7f1d1d);
          position: relative;
        }

        .chance-sep {
          color: #555;
          font-size: 18px;
          font-weight: 100;
        }

        /* RETARD GRID */
        .retard-section {
          padding: 8px 12px 12px;
        }

        .retard-title {
          font-size: 10px;
          color: #555;
          letter-spacing: 1px;
          text-transform: uppercase;
          margin-bottom: 6px;
        }

        .retard-grid {
          display: grid;
          grid-template-columns: repeat(10, 1fr);
          gap: 2px;
        }

        .retard-cell {
          border-radius: 3px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 2px 1px;
          min-height: 32px;
          cursor: default;
          transition: transform 0.1s;
        }

        .retard-cell:active { transform: scale(0.95); }

        .cell-num {
          font-size: 8px;
          font-weight: bold;
          color: rgba(0,0,0,0.5);
          line-height: 1;
        }

        .cell-val {
          font-size: 10px;
          font-weight: 900;
          color: rgba(0,0,0,0.8);
          line-height: 1;
          margin-top: 1px;
        }

        .retard-grid.chance-grid {
          grid-template-columns: repeat(10, 1fr);
        }

        /* LOADING */
        .loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 16px;
          padding: 60px 20px;
          color: #888;
        }

        .spinner {
          width: 36px;
          height: 36px;
          border: 3px solid #1f2937;
          border-top-color: #6c3fc5;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }

        .spinner.small { width: 20px; height: 20px; border-width: 2px; }

        @keyframes spin { to { transform: rotate(360deg); } }

        .loading-more {
          display: flex;
          align-items: center;
          gap: 10px;
          justify-content: center;
          padding: 20px;
          color: #888;
          font-size: 13px;
        }

        .end-message {
          text-align: center;
          color: #555;
          font-size: 12px;
          padding: 20px;
        }

        .error {
          background: #1f1010;
          border: 1px solid #7f1d1d;
          border-radius: 8px;
          padding: 16px;
          text-align: center;
          color: #fca5a5;
        }

        .error button {
          margin-top: 10px;
          background: #7f1d1d;
          border: none;
          color: white;
          padding: 8px 16px;
          border-radius: 6px;
          cursor: pointer;
          font-family: 'Courier New', monospace;
        }

        /* STATS */
        .stats-container { display: flex; flex-direction: column; gap: 14px; }

        .stats-card {
          background: #111827;
          border: 1px solid #1f2937;
          border-radius: 10px;
          padding: 14px;
        }

        .stats-card h2 {
          font-size: 13px;
          color: #c084fc;
          letter-spacing: 2px;
          text-transform: uppercase;
          margin-bottom: 12px;
          border-bottom: 1px solid #1f2937;
          padding-bottom: 8px;
        }

        .retard-bar-list { display: flex; flex-direction: column; gap: 6px; }

        .retard-bar-item {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .rbar-num {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: radial-gradient(circle at 35% 35%, #7c3aed, #4c1d95);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 11px;
          font-weight: 900;
          color: white;
          flex-shrink: 0;
        }

        .rbar-track {
          flex: 1;
          height: 18px;
          background: #1f2937;
          border-radius: 4px;
          overflow: hidden;
        }

        .rbar-fill {
          height: 100%;
          border-radius: 4px;
          display: flex;
          align-items: center;
          padding-left: 6px;
          font-size: 10px;
          font-weight: bold;
          color: rgba(0,0,0,0.7);
          transition: width 0.5s ease;
        }

        .full-retard-grid {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 3px;
        }

        .full-cell {
          border-radius: 4px;
          padding: 4px 2px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 1px;
        }

        .full-cell .cn { font-size: 9px; color: rgba(0,0,0,0.5); font-weight: bold; }
        .full-cell .cv { font-size: 11px; color: rgba(0,0,0,0.85); font-weight: 900; }

        .tableau-container { padding-bottom: 20px; }

        /* SYNC UI */
        .header-right { display: flex; align-items: center; gap: 8px; }

        .sync-btn {
          background: rgba(108,63,197,0.2);
          border: 1px solid rgba(108,63,197,0.4);
          color: #c084fc;
          width: 34px;
          height: 34px;
          border-radius: 8px;
          cursor: pointer;
          font-size: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
          flex-shrink: 0;
        }

        .sync-btn:hover { background: rgba(108,63,197,0.4); }
        .sync-btn.syncing { animation: pulse 1s ease-in-out infinite; }
        @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.4; } }

        .sync-bar {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 5px 10px;
          background: #0d1117;
          border: 1px solid #1f2937;
          border-radius: 6px;
          margin-bottom: 8px;
          font-size: 11px;
        }

        .sync-dot { font-size: 10px; font-weight: bold; letter-spacing: 1px; }
        .sync-dot.live { color: #00e676; }
        .sync-dot.mem { color: #fbbf24; }
        .sync-time { color: #6b7280; margin-left: auto; }

        .sync-msg {
          background: #0d2818;
          border: 1px solid #166534;
          color: #86efac;
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 12px;
          margin-bottom: 8px;
          text-align: center;
          animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
}

function TirageCard({ tirage }: { tirage: TirageDisplay }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="tirage-card">
      <div className="card-header" onClick={() => setExpanded(!expanded)} style={{ cursor: "pointer" }}>
        <span className="card-date">📅 {formatDate(tirage.date)}</span>
        <span className="card-label">{expanded ? "▲ réduire" : "▼ retards"}</span>
      </div>

      {/* Drawn balls */}
      <div className="drawn-balls">
        {tirage.numeros.map((n, i) => (
          <div key={i} className="ball">{n}</div>
        ))}
        <span className="chance-sep">|</span>
        <div className="ball chance">{tirage.complementaire}</div>
      </div>

      {/* Retard grids (expanded) */}
      {expanded && (
        <div className="retard-section">
          <div className="retard-title">Retards boules 1–49</div>
          <div className="retard-grid">
            {Array.from({ length: 49 }, (_, i) => i + 1).map((n) => {
              const r = tirage.retards[n] ?? 0;
              const bg = retardColor(r, MAX_RETARD_BOULE);
              return (
                <div key={n} className="retard-cell" style={{ background: bg }}>
                  <span className="cell-num">{n}</span>
                  <span className="cell-val">{r}</span>
                </div>
              );
            })}
          </div>

          <div className="retard-title" style={{ marginTop: 10 }}>Retards chance 1–10</div>
          <div className="retard-grid chance-grid">
            {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => {
              const r = tirage.retardsChance[n] ?? 0;
              const bg = retardColor(r, MAX_RETARD_CHANCE);
              return (
                <div key={n} className="retard-cell" style={{ background: bg }}>
                  <span className="cell-num">{n}</span>
                  <span className="cell-val">{r}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function StatsView({
  tirage,
  topRetards,
  allDisplayed,
}: {
  tirage: TirageDisplay;
  topRetards: { numero: number; retard: number }[];
  allDisplayed: TirageDisplay[];
}) {
  const maxRetard = Math.max(...topRetards.map((t) => t.retard), 1);

  return (
    <div className="stats-container">
      {/* Last tirage summary */}
      <div className="stats-card">
        <h2>Dernier tirage — {formatDate(tirage.date)}</h2>
        <div className="drawn-balls">
          {tirage.numeros.map((n, i) => (
            <div key={i} className="ball">{n}</div>
          ))}
          <span className="chance-sep">|</span>
          <div className="ball chance">{tirage.complementaire}</div>
        </div>
      </div>

      {/* Top retards */}
      <div className="stats-card">
        <h2>🔥 Top 10 numéros en retard</h2>
        <div className="retard-bar-list">
          {topRetards.map(({ numero, retard }) => (
            <div key={numero} className="retard-bar-item">
              <div className="rbar-num">{numero}</div>
              <div className="rbar-track">
                <div
                  className="rbar-fill"
                  style={{
                    width: `${(retard / maxRetard) * 100}%`,
                    background: retardColor(retard, MAX_RETARD_BOULE),
                  }}
                >
                  {retard}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Full grid current state */}
      <div className="stats-card">
        <h2>📊 État actuel — tous les numéros</h2>
        <div className="full-retard-grid">
          {Array.from({ length: 49 }, (_, i) => i + 1).map((n) => {
            const r = tirage.retards[n] ?? 0;
            const bg = retardColor(r, MAX_RETARD_BOULE);
            return (
              <div key={n} className="full-cell" style={{ background: bg }}>
                <span className="cn">{n}</span>
                <span className="cv">{r}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Chance grid */}
      <div className="stats-card">
        <h2>🎯 Numéros chance</h2>
        <div className="retard-grid chance-grid">
          {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => {
            const r = tirage.retardsChance[n] ?? 0;
            const bg = retardColor(r, MAX_RETARD_CHANCE);
            return (
              <div key={n} className="retard-cell" style={{ background: bg }}>
                <span className="cell-num">{n}</span>
                <span className="cell-val">{r}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
