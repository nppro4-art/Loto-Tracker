import { NextResponse } from "next/server";
import { isKVAvailable, hasData, getTotalCount, getNewestDate, getLastSync } from "@/lib/store";

// GET /api/admin — returns sync status
export async function GET() {
  const kvOk = await isKVAvailable();

  if (!kvOk) {
    return NextResponse.json({
      kvConnected: false,
      message: "KV non configuré. Voir README pour les instructions.",
    });
  }

  const [populated, total, newest, lastSync] = await Promise.all([
    hasData(),
    getTotalCount(),
    getNewestDate(),
    getLastSync(),
  ]);

  return NextResponse.json({
    kvConnected: true,
    populated,
    total,
    newestTirage: newest,
    lastSync,
    nextCron: "Lundi, Mercredi et Samedi à 22h00",
  });
}
