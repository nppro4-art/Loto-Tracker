import { NextResponse } from "next/server";
import { fetchFDJTirages } from "@/lib/fdj";
import { saveTirages, saveLastSync, getNewestDate, hasData, isKVAvailable } from "@/lib/store";

// This route is called:
//  1. By Vercel Cron: every Monday, Wednesday and Saturday at 22:00 Paris time
//  2. Manually via GET /api/sync?force=true (admin use)
//  3. On first boot when KV is empty (triggered from /api/tirages)

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const force = searchParams.get("force") === "true";
  const fullSync = searchParams.get("full") === "true";

  // Verify cron secret when called by Vercel scheduler
  // (Vercel automatically sets Authorization: Bearer <CRON_SECRET>)
  const authHeader = request.headers.get("authorization");
  const cronSecret = process.env.CRON_SECRET;
  const isCron = cronSecret && authHeader === `Bearer ${cronSecret}`;
  const isManual = !cronSecret || force; // allow manual if secret not set

  if (!isCron && !isManual) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Check KV availability
  const kvOk = await isKVAvailable();
  if (!kvOk) {
    return NextResponse.json(
      { error: "KV store not available. Configure VERCEL_KV in your project." },
      { status: 503 }
    );
  }

  try {
    const dataExists = await hasData();
    const newestDate = await getNewestDate();

    // Determine sync mode
    const isInitialSync = !dataExists || fullSync;

    console.log(`[SYNC] mode=${isInitialSync ? "FULL" : "INCREMENTAL"} newestDate=${newestDate}`);

    // Fetch from FDJ — pass newestDate so we only get newer entries (incremental)
    const sinceDate = isInitialSync ? undefined : (newestDate ?? undefined);
    const tirages = await fetchFDJTirages(sinceDate);

    console.log(`[SYNC] fetched ${tirages.length} new tirages from FDJ`);

    if (tirages.length === 0) {
      return NextResponse.json({
        status: "up_to_date",
        message: "Aucun nouveau tirage trouvé",
        newestDate,
        syncedAt: new Date().toISOString(),
      });
    }

    // Save to KV store
    const saved = await saveTirages(tirages);
    const now = new Date().toISOString();
    await saveLastSync(now);

    console.log(`[SYNC] saved ${saved} tirages. Latest: ${tirages[0]?.date}`);

    return NextResponse.json({
      status: "success",
      saved,
      latest: tirages[0]?.date,
      syncedAt: now,
      mode: isInitialSync ? "full" : "incremental",
    });
  } catch (error: any) {
    console.error("[SYNC] error:", error);
    return NextResponse.json(
      { error: error?.message || "Sync failed" },
      { status: 500 }
    );
  }
}
