import { NextResponse } from "next/server";
import { LotoTirage } from "@/lib/loto";
import { getTiragesPaginated, hasData, isKVAvailable, getTotalCount, getLastSync } from "@/lib/store";
import { fetchFDJTirages } from "@/lib/fdj";

// In-memory fallback cache (used when KV is not configured, e.g. local dev)
let memCache: { data: LotoTirage[]; ts: number } | null = null;
const MEM_CACHE_TTL = 60 * 60 * 1000; // 1 hour

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const page = parseInt(searchParams.get("page") || "1");
  const perPage = Math.min(parseInt(searchParams.get("perPage") || "50"), 100);
  const search = searchParams.get("search") || "";
  const yearFilter = search.match(/^\d{4}$/) ? search : undefined;

  try {
    const kvOk = await isKVAvailable();

    // ── KV path (production) ──────────────────────────────────────────────────
    if (kvOk) {
      // Bootstrap: if KV is empty, trigger an initial full sync inline
      const populated = await hasData();
      if (!populated) {
        console.log("[API] KV empty — running initial sync...");
        await triggerInitialSync();
      }

      const { tirages, total, totalPages } = await getTiragesPaginated(
        page,
        perPage,
        yearFilter
      );

      const lastSync = await getLastSync();
      const kvTotal = await getTotalCount();

      return NextResponse.json({
        tirages,
        total,
        page,
        perPage,
        totalPages,
        source: "kv",
        lastSync,
        kvTotal,
      });
    }

    // ── Memory fallback (local dev / no KV configured) ────────────────────────
    if (!memCache || Date.now() - memCache.ts > MEM_CACHE_TTL) {
      console.log("[API] fetching from FDJ into memory cache...");
      const tirages = await fetchFDJTirages();
      memCache = { data: tirages, ts: Date.now() };
    }

    let filtered = memCache.data;
    if (yearFilter) {
      filtered = memCache.data.filter((t) => t.date.startsWith(yearFilter));
    } else if (search) {
      filtered = memCache.data.filter((t) => t.date.includes(search));
    }

    const total = filtered.length;
    const start = (page - 1) * perPage;
    const paginated = filtered.slice(start, start + perPage);

    return NextResponse.json({
      tirages: paginated,
      total,
      page,
      perPage,
      totalPages: Math.ceil(total / perPage),
      source: "memory",
      lastSync: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("[API] error:", error);
    return NextResponse.json(
      { error: error?.message || "Impossible de charger les données" },
      { status: 500 }
    );
  }
}

// Inline initial sync when KV is empty on first request
async function triggerInitialSync() {
  try {
    const { saveTirages, saveLastSync } = await import("@/lib/store");
    const tirages = await fetchFDJTirages();
    if (tirages.length > 0) {
      await saveTirages(tirages);
      await saveLastSync(new Date().toISOString());
      console.log(`[API] initial sync complete: ${tirages.length} tirages saved`);
    }
  } catch (e) {
    console.error("[API] initial sync failed:", e);
  }
}
