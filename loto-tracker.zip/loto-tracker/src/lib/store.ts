import { Redis } from "@upstash/redis";
import { LotoTirage } from "./loto";

// ─── Redis client ─────────────────────────────────────────────────────────────
// Upstash injects UPSTASH_REDIS_REST_URL + UPSTASH_REDIS_REST_TOKEN automatically
let _redis: Redis | null = null;

function getRedis(): Redis {
  if (!_redis) {
    _redis = new Redis({
      url: process.env.UPSTASH_REDIS_REST_URL!,
      token: process.env.UPSTASH_REDIS_REST_TOKEN!,
    });
  }
  return _redis;
}

// ─── Keys ─────────────────────────────────────────────────────────────────────
const KEY_ALL_DATES = "loto:dates";
const KEY_TIRAGE = (date: string) => `loto:tirage:${date}`;
const KEY_LAST_SYNC = "loto:last_sync";
const KEY_TOTAL = "loto:total";

// ─── Write ────────────────────────────────────────────────────────────────────

export async function saveTirages(tirages: LotoTirage[]): Promise<number> {
  if (tirages.length === 0) return 0;
  const redis = getRedis();
  const pipeline = redis.pipeline();

  for (const t of tirages) {
    pipeline.set(KEY_TIRAGE(t.date), JSON.stringify(t));
    const score = new Date(t.date).getTime();
    pipeline.zadd(KEY_ALL_DATES, { score, member: t.date });
  }

  await pipeline.exec();
  const total = await redis.zcard(KEY_ALL_DATES);
  await redis.set(KEY_TOTAL, total);
  return tirages.length;
}

export async function saveLastSync(date: string): Promise<void> {
  await getRedis().set(KEY_LAST_SYNC, date);
}

// ─── Read ─────────────────────────────────────────────────────────────────────

export async function getLastSync(): Promise<string | null> {
  return getRedis().get<string>(KEY_LAST_SYNC);
}

export async function getTotalCount(): Promise<number> {
  const cached = await getRedis().get<number>(KEY_TOTAL);
  if (cached !== null && cached !== undefined) return Number(cached);
  return getRedis().zcard(KEY_ALL_DATES);
}

export interface PageResult {
  tirages: LotoTirage[];
  total: number;
  totalPages: number;
}

export async function getTiragesPaginated(
  page: number,
  perPage: number,
  yearFilter?: string
): Promise<PageResult> {
  const redis = getRedis();
  let allDates: string[];

  if (yearFilter) {
    const year = parseInt(yearFilter);
    if (!isNaN(year)) {
      const minScore = new Date(`${year}-01-01`).getTime();
      const maxScore = new Date(`${year}-12-31T23:59:59`).getTime();
      const res = await redis.zrangebyscore(KEY_ALL_DATES, minScore, maxScore);
      allDates = (res as string[]).reverse();
    } else {
      allDates = (await redis.zrange(KEY_ALL_DATES, 0, -1, { rev: true })) as string[];
    }
  } else {
    allDates = (await redis.zrange(KEY_ALL_DATES, 0, -1, { rev: true })) as string[];
  }

  const total = allDates.length;
  const totalPages = Math.ceil(total / perPage);
  const start = (page - 1) * perPage;
  const pageDates = allDates.slice(start, start + perPage);

  if (pageDates.length === 0) return { tirages: [], total, totalPages };

  const pipeline = redis.pipeline();
  for (const date of pageDates) pipeline.get(KEY_TIRAGE(date));
  const rawResults = await pipeline.exec();

  const tirages: LotoTirage[] = [];
  for (const raw of rawResults) {
    if (!raw) continue;
    try {
      const t = typeof raw === "string" ? JSON.parse(raw) : raw;
      if (t?.date) tirages.push(t as LotoTirage);
    } catch {}
  }

  return { tirages, total, totalPages };
}

export async function hasData(): Promise<boolean> {
  const total = await getRedis().zcard(KEY_ALL_DATES);
  return total > 0;
}

export async function getNewestDate(): Promise<string | null> {
  const dates = await getRedis().zrange(KEY_ALL_DATES, -1, -1);
  return dates.length > 0 ? (dates[0] as string) : null;
}

export async function isKVAvailable(): Promise<boolean> {
  if (!process.env.UPSTASH_REDIS_REST_URL || !process.env.UPSTASH_REDIS_REST_TOKEN) {
    return false;
  }
  try {
    await getRedis().ping();
    return true;
  } catch {
    return false;
  }
}
