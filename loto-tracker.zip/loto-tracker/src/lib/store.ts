import { kv } from "@vercel/kv";
import { LotoTirage } from "./loto";

// ─── Keys ─────────────────────────────────────────────────────────────────────
const KEY_ALL_DATES = "loto:dates";          // Sorted set: date → timestamp score
const KEY_TIRAGE = (date: string) => `loto:tirage:${date}`;
const KEY_LAST_SYNC = "loto:last_sync";
const KEY_TOTAL = "loto:total";

// ─── Write ────────────────────────────────────────────────────────────────────

export async function saveTirages(tirages: LotoTirage[]): Promise<number> {
  if (tirages.length === 0) return 0;
  let added = 0;

  // Use pipeline for bulk writes
  const pipeline = kv.pipeline();

  for (const t of tirages) {
    // Store tirage data as JSON hash
    pipeline.set(KEY_TIRAGE(t.date), JSON.stringify(t));
    // Add date to sorted set with timestamp as score (for range queries)
    const score = new Date(t.date).getTime();
    pipeline.zadd(KEY_ALL_DATES, { score, member: t.date });
    added++;
  }

  await pipeline.exec();

  // Update total count
  const total = await kv.zcard(KEY_ALL_DATES);
  await kv.set(KEY_TOTAL, total);

  return added;
}

export async function saveLastSync(date: string): Promise<void> {
  await kv.set(KEY_LAST_SYNC, date);
}

// ─── Read ─────────────────────────────────────────────────────────────────────

export async function getLastSync(): Promise<string | null> {
  return kv.get<string>(KEY_LAST_SYNC);
}

export async function getTotalCount(): Promise<number> {
  const cached = await kv.get<number>(KEY_TOTAL);
  if (cached !== null && cached !== undefined) return cached;
  return kv.zcard(KEY_ALL_DATES);
}

export interface PageResult {
  tirages: LotoTirage[];
  total: number;
  totalPages: number;
}

export async function getTiragesPaginated(
  page: number,
  perPage: number,
  yearFilter?: string
): Promise<PageResult> {
  // Get dates from sorted set, newest first (reverse order)
  let allDates: string[];

  if (yearFilter) {
    // Filter by year: score range from Jan 1 to Dec 31
    const year = parseInt(yearFilter);
    if (!isNaN(year)) {
      const minScore = new Date(`${year}-01-01`).getTime();
      const maxScore = new Date(`${year}-12-31T23:59:59`).getTime();
      allDates = await kv.zrangebyscore(KEY_ALL_DATES, minScore, maxScore);
      allDates.reverse(); // newest first
    } else {
      allDates = await kv.zrange(KEY_ALL_DATES, 0, -1, { rev: true });
    }
  } else {
    allDates = await kv.zrange(KEY_ALL_DATES, 0, -1, { rev: true });
  }

  const total = allDates.length;
  const totalPages = Math.ceil(total / perPage);
  const start = (page - 1) * perPage;
  const pageDates = allDates.slice(start, start + perPage);

  if (pageDates.length === 0) {
    return { tirages: [], total, totalPages };
  }

  // Fetch tirage data for this page
  const pipeline = kv.pipeline();
  for (const date of pageDates) {
    pipeline.get(KEY_TIRAGE(date));
  }
  const rawResults = await pipeline.exec();

  const tirages: LotoTirage[] = [];
  for (const raw of rawResults) {
    if (!raw) continue;
    try {
      const t = typeof raw === "string" ? JSON.parse(raw) : raw;
      if (t && t.date) tirages.push(t as LotoTirage);
    } catch {}
  }

  return { tirages, total, totalPages };
}

export async function hasData(): Promise<boolean> {
  const total = await kv.zcard(KEY_ALL_DATES);
  return total > 0;
}

export async function getNewestDate(): Promise<string | null> {
  const dates = await kv.zrange(KEY_ALL_DATES, -1, -1);
  return dates.length > 0 ? (dates[0] as string) : null;
}

// ─── Dev fallback (no KV) ─────────────────────────────────────────────────────

export async function isKVAvailable(): Promise<boolean> {
  try {
    await kv.ping();
    return true;
  } catch {
    return false;
  }
}
