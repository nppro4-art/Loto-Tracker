export interface LotoTirage {
  date: string;
  boule1: number;
  boule2: number;
  boule3: number;
  boule4: number;
  boule5: number;
  complementaire: number;
}

export interface NumeroRetard {
  numero: number;
  retard: number;
  isChance?: boolean;
}

export interface TirageDisplay {
  date: string;
  numeros: number[];
  complementaire: number;
  retards: { [key: number]: number };
  retardsChance: { [key: number]: number };
}

// Loto français: 5 boules de 1 à 49 + 1 complémentaire de 1 à 10
export const MAX_BOULE = 49;
export const MAX_CHANCE = 10;

export function computeRetards(tirages: LotoTirage[]): TirageDisplay[] {
  // Initialize retards
  const retards: { [key: number]: number } = {};
  const retardsChance: { [key: number]: number } = {};

  for (let i = 1; i <= MAX_BOULE; i++) retards[i] = 0;
  for (let i = 1; i <= MAX_CHANCE; i++) retardsChance[i] = 0;

  const result: TirageDisplay[] = [];

  // Process in chronological order
  const sorted = [...tirages].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  for (const tirage of sorted) {
    const drawn = [tirage.boule1, tirage.boule2, tirage.boule3, tirage.boule4, tirage.boule5];
    const chance = tirage.complementaire;

    // Increment all retards first
    for (let i = 1; i <= MAX_BOULE; i++) retards[i]++;
    for (let i = 1; i <= MAX_CHANCE; i++) retardsChance[i]++;

    // Reset drawn numbers
    for (const n of drawn) retards[n] = 0;
    retardsChance[chance] = 0;

    result.push({
      date: tirage.date,
      numeros: drawn,
      complementaire: chance,
      retards: { ...retards },
      retardsChance: { ...retardsChance },
    });
  }

  // Return in reverse chronological order
  return result.reverse();
}

export function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

// Color for retard value (heatmap)
export function retardColor(retard: number, max: number): string {
  if (retard === 0) return "#00e676"; // just drawn - green
  const ratio = Math.min(retard / max, 1);
  if (ratio < 0.3) return "#e8f5e9";
  if (ratio < 0.5) return "#fff9c4";
  if (ratio < 0.7) return "#ffe0b2";
  if (ratio < 0.85) return "#ffccbc";
  return "#ef9a9a";
}

export function retardTextColor(retard: number, max: number): string {
  if (retard === 0) return "#003300";
  return "#1a1a1a";
}
