import { LotoTirage } from "./loto";

// ─── FDJ Open Data sources ───────────────────────────────────────────────────
// Each ZIP contains a CSV with a specific period of draws
export const FDJ_SOURCES = [
  { url: "https://media.fdj.fr/static-draws/csv/loto/loto_202102.zip", format: "new" },
  { url: "https://media.fdj.fr/static-draws/csv/loto/loto_201911.zip", format: "new" },
  { url: "https://media.fdj.fr/static-draws/csv/loto/loto_201902.zip", format: "new" },
  { url: "https://media.fdj.fr/static-draws/csv/loto/loto_200810.zip", format: "old" },
  { url: "https://media.fdj.fr/static-draws/csv/loto/loto_199605.zip", format: "old" },
] as const;

// ─── CSV parsers ──────────────────────────────────────────────────────────────

// New format (post-2019): date_de_tirage;boule_1;boule_2;boule_3;boule_4;boule_5;numero_chance;...
function parseNewFormat(lines: string[]): LotoTirage[] {
  const results: LotoTirage[] = [];
  // Find header to locate columns dynamically
  const header = lines[0]?.toLowerCase() || "";
  const cols = header.split(";");
  const idxDate = cols.findIndex((c) => c.includes("date"));
  const idxB1 = cols.findIndex((c) => c === "boule_1");
  const idxB2 = cols.findIndex((c) => c === "boule_2");
  const idxB3 = cols.findIndex((c) => c === "boule_3");
  const idxB4 = cols.findIndex((c) => c === "boule_4");
  const idxB5 = cols.findIndex((c) => c === "boule_5");
  const idxChance = cols.findIndex((c) => c.includes("chance") || c.includes("complementaire"));

  const d = idxDate >= 0 ? idxDate : 0;
  const b1 = idxB1 >= 0 ? idxB1 : 1;
  const b2 = idxB2 >= 0 ? idxB2 : 2;
  const b3 = idxB3 >= 0 ? idxB3 : 3;
  const b4 = idxB4 >= 0 ? idxB4 : 4;
  const b5 = idxB5 >= 0 ? idxB5 : 5;
  const ch = idxChance >= 0 ? idxChance : 6;

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const parts = line.split(";");
    if (parts.length < 7) continue;

    const dateRaw = parts[d]?.trim() || "";
    const dateParts = dateRaw.split("/");
    if (dateParts.length !== 3) continue;
    const date = `${dateParts[2]}-${dateParts[1].padStart(2, "0")}-${dateParts[0].padStart(2, "0")}`;

    const n1 = parseInt(parts[b1]);
    const n2 = parseInt(parts[b2]);
    const n3 = parseInt(parts[b3]);
    const n4 = parseInt(parts[b4]);
    const n5 = parseInt(parts[b5]);
    const nc = parseInt(parts[ch]);

    if ([n1, n2, n3, n4, n5, nc].some(isNaN)) continue;
    if (n1 < 1 || n1 > 49) continue;
    const chance = nc > 10 ? (nc % 10) || 10 : nc < 1 ? 1 : nc;

    results.push({ date, boule1: n1, boule2: n2, boule3: n3, boule4: n4, boule5: n5, complementaire: chance });
  }
  return results;
}

// Old format (pre-2019): annee;mois;jour;heure;boule_1;boule_2;boule_3;boule_4;boule_5;complementaire;...
function parseOldFormat(lines: string[]): LotoTirage[] {
  const results: LotoTirage[] = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const parts = line.split(";");
    if (parts.length < 10) continue;

    const year = parts[0]?.trim();
    const month = parts[1]?.trim().padStart(2, "0");
    const day = parts[2]?.trim().padStart(2, "0");
    if (!year || !month || !day) continue;
    const date = `${year}-${month}-${day}`;

    const n1 = parseInt(parts[4]);
    const n2 = parseInt(parts[5]);
    const n3 = parseInt(parts[6]);
    const n4 = parseInt(parts[7]);
    const n5 = parseInt(parts[8]);
    const nc = parseInt(parts[9]);

    if ([n1, n2, n3, n4, n5, nc].some(isNaN)) continue;
    if (n1 < 1 || n1 > 49) continue;
    const chance = nc > 10 ? (nc % 10) || 10 : nc < 1 ? 1 : nc;

    results.push({ date, boule1: n1, boule2: n2, boule3: n3, boule4: n4, boule5: n5, complementaire: chance });
  }
  return results;
}

// ─── ZIP extractor ────────────────────────────────────────────────────────────

export async function extractCsvFromZip(buffer: ArrayBuffer): Promise<string | null> {
  try {
    const bytes = new Uint8Array(buffer);
    let offset = 0;

    while (offset < bytes.length - 30) {
      // Local file header: PK\x03\x04
      if (bytes[offset] !== 0x50 || bytes[offset + 1] !== 0x4b ||
          bytes[offset + 2] !== 0x03 || bytes[offset + 3] !== 0x04) {
        offset++;
        continue;
      }

      const compressionMethod = bytes[offset + 8] | (bytes[offset + 9] << 8);
      const compressedSize =
        (bytes[offset + 18]) | (bytes[offset + 19] << 8) |
        (bytes[offset + 20] << 16) | (bytes[offset + 21] << 24);
      const uncompressedSize =
        (bytes[offset + 22]) | (bytes[offset + 23] << 8) |
        (bytes[offset + 24] << 16) | (bytes[offset + 25] << 24);
      const filenameLength = bytes[offset + 26] | (bytes[offset + 27] << 8);
      const extraLength = bytes[offset + 28] | (bytes[offset + 29] << 8);
      const dataOffset = offset + 30 + filenameLength + extraLength;
      const filename = new TextDecoder("utf-8", { fatal: false }).decode(
        bytes.slice(offset + 30, offset + 30 + filenameLength)
      );

      if (filename.toLowerCase().endsWith(".csv")) {
        const rawData = bytes.slice(dataOffset, dataOffset + compressedSize);

        let decoded: string;
        if (compressionMethod === 0) {
          // Stored — no compression
          decoded = decodeCSVBytes(rawData);
        } else if (compressionMethod === 8) {
          // Deflate
          try {
            const ds = new DecompressionStream("deflate-raw");
            const writer = ds.writable.getWriter();
            const reader = ds.readable.getReader();
            writer.write(rawData);
            writer.close();
            const chunks: Uint8Array[] = [];
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              chunks.push(value);
            }
            const out = new Uint8Array(uncompressedSize || chunks.reduce((s, c) => s + c.length, 0));
            let pos = 0;
            for (const c of chunks) { out.set(c, pos); pos += c.length; }
            decoded = decodeCSVBytes(out);
          } catch {
            offset = dataOffset + compressedSize;
            continue;
          }
        } else {
          offset = dataOffset + compressedSize;
          continue;
        }

        return decoded;
      }

      offset = dataOffset + Math.max(compressedSize, 1);
    }
    return null;
  } catch (e) {
    console.error("ZIP extraction error:", e);
    return null;
  }
}

function decodeCSVBytes(bytes: Uint8Array): string {
  try { return new TextDecoder("utf-8", { fatal: true }).decode(bytes); }
  catch { return new TextDecoder("iso-8859-1").decode(bytes); }
}

// ─── Main fetcher ─────────────────────────────────────────────────────────────

export async function fetchFDJTirages(sinceDate?: string): Promise<LotoTirage[]> {
  const allTirages: LotoTirage[] = [];
  const seenDates = new Set<string>();
  const since = sinceDate ? new Date(sinceDate).getTime() : 0;

  for (const source of FDJ_SOURCES) {
    try {
      const res = await fetch(source.url, {
        headers: { Accept: "*/*" },
        next: { revalidate: 0 },
      });
      if (!res.ok) {
        console.warn(`FDJ source ${source.url} returned ${res.status}`);
        continue;
      }

      const buffer = await res.arrayBuffer();
      const csv = await extractCsvFromZip(buffer);
      if (!csv) { console.warn(`Could not extract CSV from ${source.url}`); continue; }

      const lines = csv.split("\n");
      const header = lines[0]?.toLowerCase() || "";
      const tirages =
        header.includes("date_de_tirage") || header.includes("boule_1")
          ? parseNewFormat(lines)
          : parseOldFormat(lines);

      for (const t of tirages) {
        if (seenDates.has(t.date)) continue;
        if (since && new Date(t.date).getTime() <= since) continue;
        seenDates.add(t.date);
        allTirages.push(t);
      }
    } catch (e) {
      console.error(`Failed to fetch ${source.url}:`, e);
    }
  }

  return allTirages.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}
